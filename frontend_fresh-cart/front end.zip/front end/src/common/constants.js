export const url = "http://localhost:8080";
//export const emailurl = "http://localhost:8081";
