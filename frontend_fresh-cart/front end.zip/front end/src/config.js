export const SERVER_BASE_URL = "http://localhost:8080";
