import React from "react";

function More() {
  return (
    <div>
      <h1>More Page</h1>
    </div>
  );
}

export default More;
