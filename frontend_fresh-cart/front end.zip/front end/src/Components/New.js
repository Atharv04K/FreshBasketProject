import React from "react";

function New() {
  return <div>New</div>;
}

export default New;
