import React from "react";
import { FaBars } from "react-icons/fa";
export const SideData = [
  {
    title: "All Category",
    icon: <FaBars />,
    link: "/home/category",
  },

  // {
  //   title: "Logout",
  //   icon: <FaUser />,
  //   link: "/",
  // },
];
